//
//  GlobalParameter.swift
//  socketchat
//
//  Created by Yen on 2018/7/18.
//  Copyright © 2018年 Simon Chang. All rights reserved.
//

import UIKit

class GlobalParameter: NSObject {
     static var piIPAddr = "http://10.3.141.111"
}
